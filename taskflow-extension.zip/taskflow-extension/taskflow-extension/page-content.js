const MAX_TEXT_LENGTH = 12000;

function extractVisibleText() {
  try {
    const raw = document.body?.innerText || "";
    return raw.replace(/\s+/g, " ").trim().slice(0, MAX_TEXT_LENGTH);
  } catch (error) {
    console.error("[TaskFlow] Failed to extract page text:", error);
    return "";
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "TASKFLOW_GET_PAGE_TEXT") return;

  sendResponse({
    ok: true,
    text: extractVisibleText()
  });
});
